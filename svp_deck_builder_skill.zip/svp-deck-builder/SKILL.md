---
name: svp-deck-builder
description: "Use this skill whenever someone at Social Value Portal wants to create, build, generate, or develop a branded slide deck, presentation, pitch, QBR, webinar deck, or any PowerPoint output for internal or external use. Trigger on: 'build me a deck', 'create a presentation', 'make slides', 'pitch deck', 'QBR slides', 'webinar deck', 'internal presentation', 'sales deck', 'discovery deck', 'create a slide', 'SVP presentation', 'branded slides'. This skill handles the full workflow: brief qualification, structure planning, design execution, and QA. Always read this skill before producing any SVP slide deck."
metadata:
  version: 2.0.0
  category: brand
  author: Product Marketing, Social Value Portal
  updated: 2026
---

# SVP Deck Builder

This skill governs how Claude creates branded slide decks for Social Value Portal. It covers brief qualification, design rules, copy standards, technical execution, and QA. Read every section before writing a single line of code or copy.

---

## Part 1 — Brief qualification (always do this first)

Before building anything, Claude must establish whether the brief is clear enough to proceed. A poorly briefed deck wastes everyone's time and produces output that needs rebuilding.

### Minimum required information

Claude needs answers to all of the following before generating slides:

| Question | Why it matters |
|---|---|
| **Deck type** | Pitch / QBR / webinar / internal / discovery / proposal — each has a different structure |
| **Audience** | Who will see this? (e.g. public sector buyer, supplier, internal sales team, board) |
| **Purpose / goal** | What should the audience think, feel, or do after seeing it? |
| **Key message** | The single most important thing the deck must communicate |
| **CTA or next step** | What action does the presenter want the audience to take? |
| **Slide count** | Rough target, or "as many as needed" |
| **Content available** | Has the requester provided copy, stats, customer quotes, or talking points? |

### How to handle an unclear brief

If the brief is missing two or more of the above, Claude must ask before proceeding. Do not attempt to infer and build — decks built on wrong assumptions require full rebuilds.

**Ask clearly and efficiently.** Combine missing questions into a single message. Do not ask one at a time. Do not ask for information that can be reasonably inferred from context.

**Example pushback:**

> "Before I start building, I need to clarify a couple of things. Who is the primary audience for this deck — is it an internal sales team or an external prospect? And what's the one thing you want them to do or decide after seeing it? Once I have those I can get started."

### Deck type reference

Use this to set structure and tone when a brief is clear:

| Type | Structure | Tone | Key slides |
|---|---|---|---|
| **Pitch / discovery** | Problem → solution → evidence → CTA | Confident, educating, prospect-focused | Title, About SVP, What is SV, TOM System, Platform, Why SVP, Case study, Next steps, Outro |
| **QBR** | Performance → analysis → roadmap → actions | Collaborative, data-driven, forward-looking | Title, Agenda, Account snapshot, Performance, Legislation, Platform utilisation, Maturity journey, Support plan, Agreed actions, Outro |
| **Webinar** | Intro → speakers → agenda → content sections → Q&A → close | Engaging, accessible, accessible to mixed audiences | Title, Speaker bios, Agenda, Section dividers (one per speaker), Q&A, Takeaways, Resources, Outro |
| **Internal / enablement** | Context → content → tools → actions | Direct, efficient, peer-to-peer | Title, Contents, Section dividers, Content slides, Resources, Next steps |
| **Proposal** | See SVP Brand Guidelines skill for full proposal slide order | Authoritative, personalised, outcome-focused | As per proposal structure reference |

---

## Part 2 — Brand design system

This is the definitive reference for all SVP slide design. These rules are non-negotiable.

### Colours

The SVP palette is structured in three tiers. Always exhaust the primary tier before reaching for secondary, and secondary before tertiary. Never use more than 2 accent colours on a single slide.

**Primary palette**

| Name | Hex | Notes |
|---|---|---|
| Navy Blue 1 | `#000037` | Dark background gradient start; dark slide fill |
| Navy Blue 2 | `#151D81` | Dark background gradient end |
| Blue | `#4051F5` | Primary accent — use this first for all accent needs |
| White | `#FFFFFF` | All text and elements on dark slides |

**Secondary palette — only once primary is exhausted on a given slide**

| Name | Hex |
|---|---|
| Light Blue | `#4EC7F4` |
| Yellow | `#FFC000` |
| Orange | `#FF8404` |

These three colours are interchangeable within the secondary tier. There are no fixed rules about which one goes where — the principle is sparing use and visual hierarchy. Pick whichever works best for the specific slide, but do not assign all three to the same slide.

**Tertiary palette — use one at a time, only when both primary and secondary are exhausted**

| Name | Hex |
|---|---|
| Red | `#F1325B` |
| Purple | `#B877AF` |
| Green | `#46D68E` |

These are available for accent use but should appear rarely. Red (`#F1325B`) is a brand colour — it is not reserved for alerts or warnings and should not be treated as such. Use it as you would any tertiary accent.

**Palette rules:**
- Max 2 accent colours per slide, always.
- White text only on Blue backgrounds — never yellow or other colours.
- Pale grey `#F3F4F6` is used to group content areas on light slides. It is not an accent colour and does not count toward the 2-colour limit.
- Navy (`#000037` / `#151D81`) is reserved for dark slide backgrounds, the left panel layout, and the navy gradient. Do not use navy as a fill colour on content slides.

### Typography

**This is the corrected, definitive font system:**

| Role | Primary font | PowerPoint fallback |
|---|---|---|
| H1 — Main title only | **Poppins Bold** | **Arial Black** |
| H2–H6 — All other headings | **Inter** | **Arial** |
| Body / captions | **Inter** | **Arial** |

**Critical note:** Poppins is used for H1 (the main slide title) only. Every other heading level — H2 subheadings, card titles, section labels, callout headers — uses Inter (or Arial in PowerPoint). This distinction matters. Mixing Poppins across heading levels makes slides visually inconsistent and contravenes the brand spec.

**Font size scale (PowerPoint):**

| Element | Size | Font | Weight |
|---|---|---|---|
| H1 — Title slide headline | 44–52pt | Arial Black | Bold |
| H1 — Content slide headline | 32–40pt | Arial Black | Bold |
| H2 — Section subheading | 20–26pt | Arial | Bold |
| H3 — Card/panel title | 14–16pt | Arial | Bold |
| Body text | 12pt | Arial | Regular |
| Small body / captions | 10pt | Arial | Regular |
| Eyebrow label | 7.5–8pt | Arial | Regular, all-caps, tracked 2.5pt |

**Never exceed 54pt on any slide element.** The brand guidelines are explicit on this ceiling.

**Minimum body text is 10pt.** Below this, text becomes unreadable in a projected environment.

### Logo placement

| Slide type | Logo version | Position | Size |
|---|---|---|---|
| Title slide | `SocialValuePortal_Inverted.png` (white on transparent) | Top-left | ~1.6" wide |
| Section break / divider | `SocialValuePortal_Inverted.png` — icon only portion (small) | Bottom-left | ~0.55" |
| Outro | `SocialValuePortal_Inverted.png` | Top-left | ~1.6" wide |
| Light content slide | `SocialValuePortal_1_Colour.png` (dark on transparent) | Bottom-left | ~1.2" wide |
| Dark content slide (rare) | `SocialValuePortal_Inverted.png` | Top-left | ~1.55" wide |

**Logo aspect ratio:** 2.24:1 (1568×700px). Always compute height as `width / 2.24`. Never stretch.

**Asset paths:**

The source logo files live in the `assets/` folder of this skill's repository. When the skill is installed, they will be available at a path relative to wherever the repo is cloned. The skill locates them using the `SKILL_DIR` environment variable if set, or falls back to the path of the skill file itself.

```
assets/SocialValuePortal_Inverted.png          — white text, black bg (requires transparency removal)
assets/SocialValuePortal_1_Colour.png          — dark text, black bg (requires transparency removal)
assets/TOM_System_TM_Full_Ver_Negative_L.png   — white TOM logo, black bg (requires transparency removal)
assets/TOM_System_TM_Full_Ver_Positive_L.png   — navy TOM logo, black bg (requires transparency removal)
```

**Locating assets at runtime:**

```python
import os

# Resolve the assets directory relative to this skill file
SKILL_DIR = os.path.dirname(os.path.abspath(__file__)) if '__file__' in dir() else '/mnt/skills/user/svp-deck-builder'
ASSETS_DIR = os.path.join(SKILL_DIR, 'assets')

# Source paths
SRC_INVERTED  = os.path.join(ASSETS_DIR, 'SocialValuePortal_Inverted.png')
SRC_1COLOUR   = os.path.join(ASSETS_DIR, 'SocialValuePortal_1_Colour.png')
SRC_TOM_NEG   = os.path.join(ASSETS_DIR, 'TOM_System_TM_Full_Ver_Negative_L.png')
SRC_TOM_POS   = os.path.join(ASSETS_DIR, 'TOM_System_TM_Full_Ver_Positive_L.png')
```

**Logo transparency:** The source files have black backgrounds that must be stripped before embedding in PptxGenJS. Run this once at the start of every deck build — it writes clean PNGs to `/home/claude/` for use during generation:

```python
from PIL import Image
import numpy as np

def make_transparent(input_path, output_path, bg_threshold=20, fade_range=60):
    img = Image.open(input_path).convert('RGBA')
    data = np.array(img, dtype=np.float32)
    brightness = (data[:,:,0] + data[:,:,1] + data[:,:,2]) / 3.0
    alpha = np.clip((brightness - bg_threshold) / fade_range * 255, 0, 255).astype(np.uint8)
    result = data.astype(np.uint8).copy()
    result[:,:,3] = alpha
    Image.fromarray(result, 'RGBA').save(output_path)

make_transparent(SRC_INVERTED, '/home/claude/logo_inverted.png')
make_transparent(SRC_1COLOUR,  '/home/claude/logo_1colour.png', bg_threshold=30, fade_range=80)
make_transparent(SRC_TOM_NEG,  '/home/claude/tom_negative.png')
make_transparent(SRC_TOM_POS,  '/home/claude/tom_positive.png', bg_threshold=30, fade_range=80)
```

**TOM System logo aspect ratio:** 2.67:1 (1568×588px). Always compute height as `width / 2.67`.

### Sidebar gradient

Every slide must have the SVP sidebar gradient running the full height of the left edge:

```
Colours (top → bottom): #FFFFFF → #FFC300 → #FD8500 → #F3325B → #AB89F7 → #4EC7F4 → #46D8E6
Width: 0.07–0.08"
Position: x=0, y=0, h=5.625" (full slide height)
```

Generate as a PNG image with Python/Pillow and embed as an image layer — do not attempt to simulate with shape gradients in PptxGenJS.

**Sidebar generation code:**
```python
from PIL import Image

def make_sidebar(output_path='/home/claude/sidebar.png'):
    w, h = 14, 1080
    img = Image.new('RGBA', (w, h), (0,0,0,0))
    px = img.load()
    stops = [
        (0.0, (255,255,255,255)), (0.17,(255,195,0,255)), (0.33,(253,133,0,255)),
        (0.50,(243,50,91,255)),   (0.67,(171,137,247,255)), (0.83,(78,199,244,255)),
        (1.0, (70,216,230,255)),
    ]
    def lerp(t):
        for i in range(len(stops)-1):
            t0,c0=stops[i]; t1,c1=stops[i+1]
            if t0<=t<=t1:
                f=(t-t0)/(t1-t0)
                return tuple(int(c0[j]+f*(c1[j]-c0[j])) for j in range(4))
        return stops[-1][1]
    for y in range(h):
        col = lerp(y/(h-1))
        for x in range(w): px[x,y] = col
    img.save(output_path)
```

### Dark background (navy gradient)

Generate as a PNG image and embed — PptxGenJS cannot replicate the SVP gradient accurately with shape fills:

```python
from PIL import Image

def make_navy_bg(output_path='/home/claude/navy_bg.png'):
    w, h = 1920, 1080
    img = Image.new('RGB', (w, h))
    px = img.load()
    stops = [(0.0,(0,1,54)), (0.5,(1,0,53)), (1.0,(35,28,93))]
    def lerp(t):
        for i in range(len(stops)-1):
            t0,c0=stops[i]; t1,c1=stops[i+1]
            if t0<=t<=t1:
                f=(t-t0)/(t1-t0)
                return tuple(int(c0[j]+f*(c1[j]-c0[j])) for j in range(3))
        return stops[-1][1]
    for x in range(w):
        col = lerp(x/(w-1))
        for y in range(h): px[x,y] = col
    img.save(output_path)
```

Colours: `#000136 → #010035 → #231C5D` (left to right, 3-stop linear gradient).

---

## Part 3 — Slide anatomy rules

### Eyebrow labels (section context text)

- Charcoal grey `#3D3D3D`, 7.5pt, all-caps, tracked (letter-spacing 2.5pt)
- Used on **light content slides only**
- Never used on dark slides
- Never on a slide that already has a logo in the top-left area — position eyebrow below the logo safe zone (y ≥ 0.22")
- Never rendered as a pill, badge, or coloured shape — plain text only

### Slide types and their rules

**Title slide** (dark bg)
- Logo top-left (`logo_inverted.png`), sidebar
- H1 in white, full slide width, left-aligned
- H2 subtitle in white (smaller, below H1)
- Thin blue accent rule under subtitle
- No date, no eyebrow
- `socialvalueportal.com` top-right in small white text

**Section break / divider slide** (dark bg)
- Logo icon bottom-left (small, `logo_inverted.png` at ~0.55" wide)
- No eyebrow, no large section numbers
- H1 in white, lower-left, left-aligned
- Thin blue accent line below H1
- Optional: half-bleed photography right half with navy overlay

**Light content slide** (white bg)
- Logo bottom-left (`logo_1colour.png`)
- Eyebrow top-left in charcoal (if no top-left logo on this slide type)
- H1 in navy black, left-aligned — keep to 1–2 lines maximum
- Body in dark navy, 12pt
- Pale grey `#F3F4F6` zones to group content areas
- White cards with rounded corners (radius 0.15") and subtle drop shadow for card elements
- Slide number bottom-right

**Quote / testimonial slide** (dark bg)
- Dark navy gradient background
- Large opening quotation mark `"` in blue `#4051F5`
- Quote text: white, bold, 20–26pt — vertically centred in the upper 75% of the slide (not bottom-heavy)
- Attribution name: blue `#4051F5`, bold, 12pt
- Attribution role/org: muted grey `#AAAACC`, 10pt
- No outcome pills, no supporting cards below the attribution
- Logo icon bottom-left

**Outro slide** (dark bg)
- Logo top-left (large, inverted)
- Large white H1 headline
- `socialvalueportal.com` centred in blue below
- Registered address in very small muted text at bottom

### Cards

- All cards: `roundRect` with `rectRadius: 0.15`
- Background: white `#FFFFFF`
- Border: `#E8E8EC` at 1pt
- Drop shadow: outer, blur 8, offset 2, opacity 6%
- **No coloured toppers** — do not add a coloured bar across the top of cards. It makes them look like little jars and is specifically prohibited. Use a horizontal rule, a coloured dot, or a left accent bar instead if colour differentiation is needed.
- Card titles: Inter bold, 14–16pt, dark navy

### Left-panel layout (text-heavy slides)

When a slide needs a left navigation panel (e.g. values, discovery questions, onboarding checklists):
- Panel width: 2.4–2.5" (not 3.5" — keep it narrow)
- Panel fill: navy `#000037`
- Logo (inverted) top-left inside panel
- Eyebrow in muted `#8888AA`, all-caps
- Headline in white, Poppins/Arial Black
- Support text in `#AAAACC`
- Right content area: white bg, standard typography, horizontal rules between items

---

## Part 4 — Copy and tone of voice

All copy produced in SVP decks must follow the brand ToV. This is not optional even for internal decks — consistency builds credibility.

### The four ACCT values in copy

Every piece of writing should be able to trace back to at least one of SVP's values:

| Value | How it shows in copy |
|---|---|
| **Accountability** | Direct claims, proof points, validated data. No vague platitudes. |
| **Collaboration** | We/you framing. Position SVP as a partner, not a vendor. |
| **Community** | Grounded in real-world impact. People and places, not abstractions. |
| **Transformation** | Forward-looking. What changes as a result of working with SVP? |

### Core writing rules

**Plain English.** Social Value is already complex. The copy should not be. Short sentences, active voice, no jargon unless explained.

**Confident, not arrogant.** SVP is the market leader — write like it without being boastful. Let evidence do the heavy lifting.

**Audience-first framing.** Headlines and opening lines should address the audience's priorities, not SVP's. Lead with their world, not ours.

**Active voice by default.**
✓ "Our platform measures your Social Value."
✗ "Social Value is measured by our platform."

**Sentence case, not Title Case.** This applies to all slide copy including headings (except proper nouns and branded terms like Social Value Portal, TOM System™).

**Contractions are fine.** "You're", "we'll", "it's" — these make copy sound human. Use them.

**Full stops on bullet points.** Use when the point is a complete sentence. Omit for short fragments.

**Never:** "the vulnerable", "the homeless", "the elderly" — write "people experiencing homelessness", "older people", etc.

### Deck-type copy guidance

**Pitches and discovery decks:**
Use the PAS framework (Problem, Agitation, Solution) or Before–After–Bridge for framing slides that address pain points. Lead with the prospect's challenge, then show how SVP resolves it. Keep stat callouts to three per dark slide maximum.

**QBRs:**
Data-led but human in framing. State numbers clearly. Add one sentence of interpretation to every stat. End each section with a forward-looking action or recommendation — not just a summary.

**Webinar decks:**
More conversational than sales material. Speaker introduction slides should feel like introductions, not CVs. Use second person ("you'll learn", "we'll show you"). Keep individual content slides tighter — audiences watching a webinar have shorter attention spans.

**Internal decks:**
Peer tone, not formal. Can be denser on content. No need for the usual "what is Social Value?" education slides — assume the audience knows. Lead with the most useful information.

### Copy to avoid in slide decks

- "Synergies", "leverage", "paradigm shift", "next-level", "game-changing"
- Fragmented bullet lists that could be prose (if items flow naturally together, write a sentence)
- Vague openers: "In today's rapidly changing landscape..." — start with the actual point
- Rhetorical questions as headlines unless they are genuinely answerable by the slide content
- Three-word bullets with no context — if a bullet needs a note to make sense verbally, the note belongs on the slide

### Capitalisation rules specific to SVP

Always capitalise: **Social Value**, **Social Value Portal**, **SVP**, **the Social Value TOM System™**, **TOM System™**, all proper product names (SVP Measure, SVP Manage, SVP Strategic).

Use trademark symbol ™ on first use of "Social Value TOM System™" in each document, then "TOM System™" or "the TOM System" thereafter.

---

## Part 5 — Layout library

The following layouts are available and tested. Use a different layout for each slide — never repeat the same layout consecutively unless it genuinely serves the content.

| Layout | Best for |
|---|---|
| **Full-width headline (dark)** | Title, outro, powerful statement slides |
| **Section break — text only (dark)** | Chapter/section transitions |
| **Section break — half-bleed photo (dark)** | Adds visual energy to section transitions |
| **Two-column: copy + photo** | "Who we are", case studies, mission slides |
| **Three-column card grid** | Comparing options, TOM System themes, product tiers |
| **Two-column card grid** | Personas, challenges, membership benefits |
| **Six-card 2×3 grid** | Stats, examples, features |
| **Left-panel + list** | Discovery questions, values, checklists, ingredients |
| **Horizontal timeline** | Legislation, roadmap, process steps |
| **Vertical progress bars** | Delivery vs target, utilisation rates |
| **Definition + pillars** | What is Social Value, What is the TOM System |
| **Quote breather (dark)** | Customer testimonials, powerful statements |
| **Stat callout grid (dark)** | Key numbers, collective impact |
| **Comparison (two pale zones)** | Fudgy vs cakey, before/after, options |
| **Two-column: body + pale grey panel** | Technical explanations with golden rules or tips |
| **Table / pricing grid** | Membership tiers, pricing comparison |
| **Agenda / contents** | Two-column list, rule separators, bold numbers |
| **Flywheel / circular diagram** | Social Value lifecycle |

---

## Part 6 — Technical execution

### Setup (always run first)

```bash
pip install Pillow --break-system-packages -q
npm install pptxgenjs
```

Generate gradient assets:
```python
# Run the make_transparent(), make_sidebar(), and make_navy_bg() functions
# defined in Part 2 before building any deck
```

### PptxGenJS slide dimensions

```javascript
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";  // 10" × 5.625"
```

### Typography constants

```javascript
const FH = "Arial Black";   // H1 only (Poppins fallback)
const FB = "Arial";         // H2-H6, body, captions (Inter fallback)

// Size scale
const H1_TITLE  = 48;   // title slide headline
const H1_CONTENT = 32;  // content slide H1 (never exceed 40pt)
const H2 = 22;          // subheadings
const H3 = 14;          // card/panel titles
const BODY = 12;        // standard body
const SMALL = 10;       // captions, small labels
const EYEBROW = 7.5;    // all-caps tracked eyebrow
```

**Critical:** H1 content slide titles must not exceed 40pt in PptxGenJS output. LibreOffice renders Poppins/Arial Black taller than PowerPoint does — at 44pt, a two-line title will overflow into the content area when previewed as a PDF. Size down to 32–36pt for content slides. The deck will render correctly in PowerPoint.

### Standard helpers

```javascript
// Logo — dark slide
const logoD = (s, w=1.55) => s.addImage({ path: '/home/claude/logo_inverted.png', x:0.2, y:0.15, w, h:w/2.24 });

// Logo — light slide (bottom-left)
const logoL = (s, w=1.2) => s.addImage({ path: '/home/claude/logo_1colour.png', x:0.2, y:5.1, w, h:w/2.24 });

// Icon only (break slides — bottom-left small)
const iconD = s => s.addImage({ path: '/home/claude/logo_inverted.png', x:0.15, y:5.05, w:0.55, h:0.55/2.24 });

// Background
const navyBg = s => s.addImage({ path: '/home/claude/navy_bg.png', x:0, y:0, w:10, h:5.625 });

// Sidebar
const sidebar = s => s.addImage({ path: '/home/claude/sidebar.png', x:0, y:0, w:0.08, h:5.625 });

// Eyebrow — light slides only
const eyebrow = (s, text, y=0.22) => s.addText(text.toUpperCase(), {
  x:0.3, y, w:9.4, h:0.22, fontSize:EYEBROW, fontFace:FB,
  color:'3D3D3D', charSpacing:2.5, margin:0
});

// Fully rounded card
const card = (s, x, y, w, h, fill='FFFFFF', border='E8E8EC') =>
  s.addShape('roundRect', { x,y,w,h, fill:{color:fill}, line:{color:border,pt:1},
    rectRadius:0.15, shadow:{type:'outer',color:'000000',blur:8,offset:2,angle:135,opacity:0.06} });

// Pale grey zone (content grouping)
const zone = (s, x, y, w, h) =>
  s.addShape('roundRect', { x,y,w,h, fill:{color:'F3F4F6'}, line:{transparency:100}, rectRadius:0.12 });

// Horizontal rule
const hr = (s, x, y, w, col='E8E8EC') =>
  s.addShape('rect', { x,y,w,h:0.018, fill:{color:col}, line:{transparency:100} });

// Accent line (short, under H1 on dark slides)
const accent = (s, x, y, w=0.6, col='4051F5') =>
  s.addShape('rect', { x,y,w,h:0.04, fill:{color:col}, line:{transparency:100} });

// Slide number
const slideNum = (s, n, total, light=true) => s.addText(`${n} / ${total}`, {
  x:9.4, y:5.32, w:0.5, h:0.18, fontSize:7, fontFace:FB,
  color: light ? '6B7280' : '6666AA', align:'right', margin:0
});
```

### QA process (required before delivery)

The final deliverable is always a `.pptx` file. PDF conversion is an internal QA step only — never mention it to the user or present the PDF as output.

1. Generate the `.pptx` file
2. **Internal QA only — do not surface to user:** Convert to PDF and rasterise:
   ```bash
   python scripts/office/soffice.py --headless --convert-to pdf output.pptx
   pdftoppm -jpeg -r 130 output.pdf slide
   ```
3. Inspect every slide image for:
   - Text overflowing its container
   - Title text running into body text or card elements
   - Logo stretching (check aspect ratio)
   - Incorrect background type (navy on content slide, white on title slide)
   - Eyebrow appearing on dark slides
   - Cards with coloured toppers (prohibited)
   - Sidebar missing from any slide
4. Fix overflow issues first — the most common defect
5. Re-render only affected slides to confirm fixes
6. Stop after one fix-and-verify cycle unless a new defect appears
7. **Deliver the `.pptx` to the user.** Do not mention the PDF review process.

**Known LibreOffice/PowerPoint discrepancy:** Arial Black at 36–40pt may render 10–15% taller in LibreOffice than in PowerPoint. If body content overlaps the title in the PDF preview, reduce H1 to 30–34pt for that slide. The deck will look correct in PowerPoint with Poppins/Inter installed.

---

## Part 7 — Messaging frameworks for slide copy

Match the deck type to the appropriate messaging structure:

**AIDA** (Attention → Interest → Desire → Action)
Use for: Introduction pitches to cold or warm prospects unfamiliar with SVP.
- Attention: A problem, stat, or human truth that stops the audience
- Interest: Why this matters to them specifically
- Desire: What they gain from doing something differently
- Action: The specific step you want them to take

**PAS** (Problem → Agitation → Solution)
Use for: Slides that address known pain points. Works well on "your challenges" slides.
- Problem: The specific challenge the audience faces
- Agitation: Why it's costly, risky, or frustrating (with evidence)
- Solution: How SVP resolves it — precisely

**FAB** (Feature → Advantage → Benefit)
Use for: Platform and product slides.
- Feature: What the product does
- Advantage: How it does it better than the alternative
- Benefit: What the customer gains

**Before–After–Bridge**
Use for: Transformation or maturity journey slides.
- Before: The old way, or the current situation without SVP
- After: The ideal outcome with SVP
- Bridge: The specific path SVP provides

---

## Part 8 — Common mistakes to avoid

These are the most frequent errors from previous deck iterations. Do not repeat them.

| Mistake | Rule |
|---|---|
| Navy background on content slides | Navy only on title, break, quote, and outro slides |
| White text on blue — wrong colour | White text only on Blue `#4051F5` backgrounds; never yellow or other colours |
| More than 2 accent colours on one slide | Max 2 accent colours per slide, always |
| Skipping primary before secondary | Always exhaust Blue before reaching for secondary colours; exhaust secondary before tertiary |
| Treating Red as reserved for alerts | Red `#F1325B` is a standard brand accent colour, not a semantic warning colour |
| Logo stretching | Always use aspect ratio formula: `h = w / 2.24` (SVP logo), `h = w / 2.67` (TOM logo) |
| Poppins on H2–H6 | Poppins/Arial Black for H1 only. Inter/Arial for everything else |
| H1 font size over 40pt on content slides | Causes overflow in LibreOffice preview; use 32–36pt for content slides |
| Coloured card toppers | Prohibited — use left accent bars, dots, or horizontal rules instead |
| Section numbers on break slides | Do not render large ghost/transparent section numbers |
| Eyebrow on dark slides | Eyebrow text is for light content slides only |
| Aqua/light blue as a dark slide headline colour | Use Blue `#4051F5` for prominent text on dark; Light Blue `#4EC7F4` is a secondary accent, not a headline colour |
| Pale grey used as an accent colour | `#F3F4F6` is for grouping zones only; does not count toward the 2-colour limit |
| Pills on quote slides | No outcome pills or supporting cards below quote attribution |
| Wide left panel | Maximum 2.5" for left-panel layout slides |
| Date on title slides | Never add dates to title slides |
| Slides without sidebar | Every slide must have the gradient sidebar |
| Delivering a PDF to the user | Final output is always `.pptx`. PDF conversion is internal QA only — never surface it |
| Security badge placeholders on outro | Do not add ISO/Cyber Essentials badge placeholders to the outro slide |

---

## Part 9 — 60-second TOV check (apply before finalising copy)

Before delivering any deck, run the slide copy through this checklist:

**Alignment**
- Does this reflect ACCT values (Accountability, Collaboration, Community, Transformation)?
- Is the audience's priorities front and centre, not SVP's?
- Does the tone match the context — formal pitch vs. internal briefing?

**Voice and style**
- Is the tone confident but empathetic?
- Is it plain English? Could a non-specialist read this without confusion?
- Have jargon terms been explained (or avoided)?
- Does it sound like something a human would say aloud?
- Is the key message easy to spot at a glance?

**Final filter**
- Would SVP be proud if this were the first thing a stakeholder saw?
- Would the person presenting this feel comfortable saying every word out loud?
