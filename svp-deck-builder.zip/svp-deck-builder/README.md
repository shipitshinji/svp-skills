# SVP Deck Builder (Claude Skill)

A Claude skill for building on-brand Social Value Portal slide decks: QBRs, pitch decks, webinar decks, sales and discovery decks, and other internal or external PowerPoint output. It covers brief qualification, design rules, copy standards, technical execution, and QA.

## What's in here

```
svp-deck-builder/
├── SKILL.md          # the skill itself
├── README.md         # this file
└── assets/           # official SVP and TOM System logo files
    ├── SocialValuePortal_Inverted.png
    ├── SocialValuePortal_1_Colour.png
    ├── SocialValuePortal_Master.png
    ├── TOM_System_TM_Full_Ver_Negative_L.png
    └── TOM_System_TM_Full_Ver_Positive_L.png
```

The logo files ship with the skill so decks are built with the correct official assets. The skill makes their black backgrounds transparent at runtime, so no manual editing is needed.

## How to install

**Claude Code / claude.ai with file access:** download this folder (or the release `.zip`), unzip it, and drop the whole `svp-deck-builder/` folder into your skills directory. Claude reads `SKILL.md` and resolves the `assets/` paths relative to it.

**Claude Projects / custom setups:** add the folder wherever your instance loads skills from, keeping the `assets/` subfolder alongside `SKILL.md` so the relative paths resolve.

Keep `SKILL.md` and `assets/` together. Moving the images out will break logo placement.

## Notes

- British English throughout. All-Arial font system.
- The logo files are JPEG-encoded despite the `.png` extension; the skill handles them correctly.
- Logos are SVP property and intended for use in SVP decks.
